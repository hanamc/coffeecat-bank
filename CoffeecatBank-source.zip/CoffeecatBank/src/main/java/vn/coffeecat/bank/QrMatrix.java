package vn.coffeecat.bank;

import java.awt.image.BufferedImage;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Bo tao ma QR tu viet (byte mode, muc sua loi M, version 1-15) va tao payload VietQR (NAPAS 247).
 * Chay hoan toan trong server, khong can mang, khong can thu vien ngoai.
 */
final class QrMatrix {

    private static final int MAX_VERSION = 15;
    private static final int[] ECC_PER_BLOCK = {-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24};
    private static final int[] NUM_BLOCKS = {-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10};

    final int size;
    private final int version;
    private final boolean[][] modules;
    private final boolean[][] isFunction;

    private QrMatrix(int version, byte[] dataCodewords) {
        this.version = version;
        this.size = version * 4 + 17;
        this.modules = new boolean[size][size];
        this.isFunction = new boolean[size][size];

        drawFunctionPatterns();
        byte[] all = addEccAndInterleave(dataCodewords);
        drawCodewords(all);

        int bestMask = 0;
        int minPenalty = Integer.MAX_VALUE;
        for (int m = 0; m < 8; m++) {
            applyMask(m);
            drawFormatBits(m);
            int p = penalty();
            if (p < minPenalty) { minPenalty = p; bestMask = m; }
            applyMask(m); // XOR lan nua de hoan tac
        }
        applyMask(bestMask);
        drawFormatBits(bestMask);
    }

    // ================= API =================

    static QrMatrix encode(String text) {
        byte[] data = text.getBytes(StandardCharsets.UTF_8);
        int version = 1;
        for (; ; version++) {
            if (version > MAX_VERSION) throw new IllegalArgumentException("Noi dung QR qua dai");
            int cap = numDataCodewords(version) * 8;
            int ccBits = version < 10 ? 8 : 16;
            if (4 + ccBits + data.length * 8 <= cap) break;
        }
        int cap = numDataCodewords(version) * 8;
        List<Integer> bits = new ArrayList<>();
        appendBits(bits, 0x4, 4); // byte mode
        appendBits(bits, data.length, version < 10 ? 8 : 16);
        for (byte b : data) appendBits(bits, b & 0xFF, 8);
        appendBits(bits, 0, Math.min(4, cap - bits.size()));
        appendBits(bits, 0, (8 - bits.size() % 8) % 8);
        for (int pad = 0xEC; bits.size() < cap; pad ^= 0xEC ^ 0x11) appendBits(bits, pad, 8);
        byte[] cw = new byte[bits.size() / 8];
        for (int i = 0; i < bits.size(); i++) cw[i >>> 3] |= bits.get(i) << (7 - (i & 7));
        return new QrMatrix(version, cw);
    }

    boolean get(int x, int y) {
        return x >= 0 && x < size && y >= 0 && y < size && modules[y][x];
    }

    /** Ve ra anh vuong `px` x `px`, nen trang, QR can giua, quiet zone 4 o. */
    BufferedImage toImage(int px) {
        int border = 4;
        int scale = Math.max(1, px / (size + border * 2));
        int total = size * scale;
        int off = (px - total) / 2;
        BufferedImage img = new BufferedImage(px, px, BufferedImage.TYPE_INT_RGB);
        for (int y = 0; y < px; y++) for (int x = 0; x < px; x++) img.setRGB(x, y, 0xFFFFFF);
        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
                if (!modules[y][x]) continue;
                for (int dy = 0; dy < scale; dy++)
                    for (int dx = 0; dx < scale; dx++)
                        img.setRGB(off + x * scale + dx, off + y * scale + dy, 0x000000);
            }
        }
        return img;
    }

    // ================= VietQR =================

    private static final Map<String, String> BANK_BIN = Map.ofEntries(
            Map.entry("VCB", "970436"), Map.entry("TCB", "970407"), Map.entry("MB", "970422"),
            Map.entry("ACB", "970416"), Map.entry("BIDV", "970418"), Map.entry("VPB", "970432"),
            Map.entry("TPB", "970423"), Map.entry("STB", "970403"), Map.entry("VIB", "970441"),
            Map.entry("ICB", "970415"), Map.entry("CTG", "970415"), Map.entry("VBA", "970405"),
            Map.entry("AGRIBANK", "970405"), Map.entry("SHB", "970443"), Map.entry("HDB", "970437"),
            Map.entry("OCB", "970448"), Map.entry("MSB", "970426"), Map.entry("EIB", "970431"),
            Map.entry("SCB", "970429"), Map.entry("LPB", "970449"), Map.entry("SEAB", "970440"),
            Map.entry("NAB", "970428"), Map.entry("BAB", "970409"), Map.entry("ABB", "970425"),
            Map.entry("VAB", "970427"), Map.entry("NCB", "970419"), Map.entry("PGB", "970430"),
            Map.entry("VIETBANK", "970433"), Map.entry("BVB", "970438"), Map.entry("KLB", "970452"),
            Map.entry("CAKE", "546034"), Map.entry("UBANK", "546035"));

    /** Tra ve ma BIN (6 so) cua ngan hang, hoac null neu khong biet. bank-id co the la ma ngan hang hoac chinh BIN. */
    static String bankBin(String bankId) {
        if (bankId == null) return null;
        String b = bankId.trim().toUpperCase(Locale.ROOT);
        if (b.matches("\\d{6}")) return b;
        return BANK_BIN.get(b);
    }

    private static String tlv(String id, String value) {
        return id + String.format("%02d", value.length()) + value;
    }

    /** Payload VietQR chuyen nhanh NAPAS 247 toi so tai khoan, co so tien va noi dung. */
    static String vietQrPayload(String bin, String account, long amount, String addInfo) {
        String merchant = tlv("00", "A000000727")
                + tlv("01", tlv("00", bin) + tlv("01", account))
                + tlv("02", "QRIBFTTA");
        String p = tlv("00", "01") + tlv("01", "12") + tlv("38", merchant) + tlv("53", "704")
                + tlv("54", String.valueOf(amount)) + tlv("58", "VN")
                + tlv("62", tlv("08", addInfo)) + "6304";
        return p + String.format("%04X", crc16(p));
    }

    static int crc16(String s) {
        int crc = 0xFFFF;
        for (byte b : s.getBytes(StandardCharsets.US_ASCII)) {
            crc ^= (b & 0xFF) << 8;
            for (int i = 0; i < 8; i++) crc = (crc & 0x8000) != 0 ? ((crc << 1) ^ 0x1021) & 0xFFFF : (crc << 1) & 0xFFFF;
        }
        return crc;
    }

    // ================= QR core =================

    private static void appendBits(List<Integer> bb, int val, int len) {
        for (int i = len - 1; i >= 0; i--) bb.add((val >>> i) & 1);
    }

    private static int numRawDataModules(int ver) {
        int size = ver * 4 + 17;
        int result = size * size;
        result -= 8 * 8 * 3;
        result -= 15 * 2 + 1;
        result -= (size - 16) * 2;
        if (ver >= 2) {
            int numAlign = ver / 7 + 2;
            result -= (numAlign - 1) * (numAlign - 1) * 25;
            result -= (numAlign - 2) * 20 * 2;
            if (ver >= 7) result -= 6 * 3 * 2;
        }
        return result;
    }

    private static int numDataCodewords(int ver) {
        return numRawDataModules(ver) / 8 - ECC_PER_BLOCK[ver] * NUM_BLOCKS[ver];
    }

    private byte[] addEccAndInterleave(byte[] data) {
        int numBlocks = NUM_BLOCKS[version];
        int blockEccLen = ECC_PER_BLOCK[version];
        int rawCodewords = numRawDataModules(version) / 8;
        int numShortBlocks = numBlocks - rawCodewords % numBlocks;
        int shortBlockLen = rawCodewords / numBlocks;

        byte[][] blocks = new byte[numBlocks][];
        byte[] div = rsDivisor(blockEccLen);
        for (int i = 0, k = 0; i < numBlocks; i++) {
            byte[] dat = Arrays.copyOfRange(data, k, k + shortBlockLen - blockEccLen + (i < numShortBlocks ? 0 : 1));
            k += dat.length;
            byte[] block = Arrays.copyOf(dat, shortBlockLen + 1);
            byte[] ecc = rsRemainder(dat, div);
            System.arraycopy(ecc, 0, block, block.length - blockEccLen, ecc.length);
            blocks[i] = block;
        }
        byte[] result = new byte[rawCodewords];
        for (int i = 0, k = 0; i < blocks[0].length; i++) {
            for (int j = 0; j < blocks.length; j++) {
                if (i != shortBlockLen - blockEccLen || j >= numShortBlocks) {
                    result[k++] = blocks[j][i];
                }
            }
        }
        return result;
    }

    private static byte[] rsDivisor(int degree) {
        byte[] result = new byte[degree];
        result[degree - 1] = 1;
        int root = 1;
        for (int i = 0; i < degree; i++) {
            for (int j = 0; j < degree; j++) {
                result[j] = (byte) gfMul(result[j] & 0xFF, root);
                if (j + 1 < degree) result[j] ^= result[j + 1];
            }
            root = gfMul(root, 0x02);
        }
        return result;
    }

    private static byte[] rsRemainder(byte[] data, byte[] divisor) {
        byte[] result = new byte[divisor.length];
        for (byte b : data) {
            int factor = (b ^ result[0]) & 0xFF;
            System.arraycopy(result, 1, result, 0, result.length - 1);
            result[result.length - 1] = 0;
            for (int i = 0; i < result.length; i++) result[i] ^= gfMul(divisor[i] & 0xFF, factor);
        }
        return result;
    }

    private static int gfMul(int x, int y) {
        int z = 0;
        for (int i = 7; i >= 0; i--) {
            z = (z << 1) ^ ((z >>> 7) * 0x11D);
            z ^= ((y >>> i) & 1) * x;
        }
        return z;
    }

    private void setFunction(int x, int y, boolean dark) {
        modules[y][x] = dark;
        isFunction[y][x] = true;
    }

    private void drawFunctionPatterns() {
        for (int i = 0; i < size; i++) {
            setFunction(6, i, i % 2 == 0);
            setFunction(i, 6, i % 2 == 0);
        }
        drawFinder(3, 3);
        drawFinder(size - 4, 3);
        drawFinder(3, size - 4);
        int[] pos = alignmentPositions();
        int n = pos.length;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (!((i == 0 && j == 0) || (i == 0 && j == n - 1) || (i == n - 1 && j == 0))) {
                    drawAlignment(pos[i], pos[j]);
                }
            }
        }
        drawFormatBits(0);
        drawVersion();
    }

    private void drawFormatBits(int mask) {
        int data = 0 << 3 | mask; // muc sua loi M co formatBits = 0
        int rem = data;
        for (int i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
        int bits = (data << 10 | rem) ^ 0x5412;
        for (int i = 0; i <= 5; i++) setFunction(8, i, bit(bits, i));
        setFunction(8, 7, bit(bits, 6));
        setFunction(8, 8, bit(bits, 7));
        setFunction(7, 8, bit(bits, 8));
        for (int i = 9; i < 15; i++) setFunction(14 - i, 8, bit(bits, i));
        for (int i = 0; i < 8; i++) setFunction(size - 1 - i, 8, bit(bits, i));
        for (int i = 8; i < 15; i++) setFunction(8, size - 15 + i, bit(bits, i));
        setFunction(8, size - 8, true);
    }

    private void drawVersion() {
        if (version < 7) return;
        int rem = version;
        for (int i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1F25);
        int bits = version << 12 | rem;
        for (int i = 0; i < 18; i++) {
            boolean b = bit(bits, i);
            int a = size - 11 + i % 3;
            int c = i / 3;
            setFunction(a, c, b);
            setFunction(c, a, b);
        }
    }

    private void drawFinder(int cx, int cy) {
        for (int dy = -4; dy <= 4; dy++) {
            for (int dx = -4; dx <= 4; dx++) {
                int dist = Math.max(Math.abs(dx), Math.abs(dy));
                int xx = cx + dx, yy = cy + dy;
                if (xx >= 0 && xx < size && yy >= 0 && yy < size) setFunction(xx, yy, dist != 2 && dist != 4);
            }
        }
    }

    private void drawAlignment(int cx, int cy) {
        for (int dy = -2; dy <= 2; dy++)
            for (int dx = -2; dx <= 2; dx++)
                setFunction(cx + dx, cy + dy, Math.max(Math.abs(dx), Math.abs(dy)) != 1);
    }

    private int[] alignmentPositions() {
        if (version == 1) return new int[0];
        int n = version / 7 + 2;
        int step = (version * 4 + n * 2 + 1) / (n * 2 - 2) * 2;
        int[] result = new int[n];
        result[0] = 6;
        for (int i = n - 1, pos = size - 7; i >= 1; i--, pos -= step) result[i] = pos;
        return result;
    }

    private void drawCodewords(byte[] data) {
        int i = 0;
        for (int right = size - 1; right >= 1; right -= 2) {
            if (right == 6) right = 5;
            for (int vert = 0; vert < size; vert++) {
                for (int j = 0; j < 2; j++) {
                    int x = right - j;
                    boolean upward = ((right + 1) & 2) == 0;
                    int y = upward ? size - 1 - vert : vert;
                    if (!isFunction[y][x] && i < data.length * 8) {
                        modules[y][x] = bit(data[i >>> 3], 7 - (i & 7));
                        i++;
                    }
                }
            }
        }
    }

    private void applyMask(int mask) {
        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
                boolean invert;
                switch (mask) {
                    case 0: invert = (x + y) % 2 == 0; break;
                    case 1: invert = y % 2 == 0; break;
                    case 2: invert = x % 3 == 0; break;
                    case 3: invert = (x + y) % 3 == 0; break;
                    case 4: invert = (x / 3 + y / 2) % 2 == 0; break;
                    case 5: invert = x * y % 2 + x * y % 3 == 0; break;
                    case 6: invert = (x * y % 2 + x * y % 3) % 2 == 0; break;
                    default: invert = ((x + y) % 2 + x * y % 3) % 2 == 0; break;
                }
                if (invert && !isFunction[y][x]) modules[y][x] = !modules[y][x];
            }
        }
    }

    /** Diem phat theo 4 quy tac cua chuan QR (chi de chon mask dep, mask nao cung quet duoc). */
    private int penalty() {
        int result = 0;
        // Quy tac 1: day >= 5 o cung mau (hang + cot)
        for (int pass = 0; pass < 2; pass++) {
            for (int a = 0; a < size; a++) {
                int run = 1;
                for (int b = 1; b < size; b++) {
                    boolean cur = pass == 0 ? modules[a][b] : modules[b][a];
                    boolean prev = pass == 0 ? modules[a][b - 1] : modules[b - 1][a];
                    if (cur == prev) {
                        run++;
                        if (run == 5) result += 3; else if (run > 5) result++;
                    } else run = 1;
                }
            }
        }
        // Quy tac 2: khoi 2x2 cung mau
        for (int y = 0; y < size - 1; y++)
            for (int x = 0; x < size - 1; x++) {
                boolean c = modules[y][x];
                if (c == modules[y][x + 1] && c == modules[y + 1][x] && c == modules[y + 1][x + 1]) result += 3;
            }
        // Quy tac 3: mau giong finder 1011101 co 4 o sang ke ben
        int[] pat = {1, 0, 1, 1, 1, 0, 1};
        for (int pass = 0; pass < 2; pass++) {
            for (int a = 0; a < size; a++) {
                for (int b = 0; b + 7 <= size; b++) {
                    boolean ok = true;
                    for (int k = 0; k < 7 && ok; k++) {
                        boolean v = pass == 0 ? modules[a][b + k] : modules[b + k][a];
                        if (v != (pat[k] == 1)) ok = false;
                    }
                    if (!ok) continue;
                    boolean lightBefore = true, lightAfter = true;
                    for (int k = 1; k <= 4; k++) {
                        int i1 = b - k, i2 = b + 6 + k;
                        if (i1 < 0 || (pass == 0 ? modules[a][i1] : modules[i1][a])) lightBefore = false;
                        if (i2 >= size || (pass == 0 ? modules[a][i2] : modules[i2][a])) lightAfter = false;
                    }
                    if (lightBefore || lightAfter) result += 40;
                }
            }
        }
        // Quy tac 4: ti le o toi
        int dark = 0;
        for (boolean[] row : modules) for (boolean m : row) if (m) dark++;
        int total = size * size;
        int k = (Math.abs(dark * 20 - total * 10) + total - 1) / total - 1;
        result += Math.max(0, k) * 10;
        return result;
    }

    private static boolean bit(int x, int i) {
        return ((x >>> i) & 1) != 0;
    }
}
