package vn.coffeecat.bank;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.MapMeta;
import org.bukkit.map.MapCanvas;
import org.bukkit.map.MapRenderer;
import org.bukkit.map.MapView;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.stream.Collectors;

public class CoffeecatBank extends JavaPlugin implements TabExecutor, Listener {

    private static final String ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    private static final String PENDING = "PENDING";
    private static final String PAID = "PAID";
    private static final String EXPIRED = "EXPIRED";
    private static final String CANCELLED = "CANCELLED";
    private static final String DONE = "DONE";
    private static final String FAILED = "FAILED";

    private static class Order {
        String code;
        UUID uuid;
        String name;
        long amount;
        long created;
        String status = PENDING;
        long paidAmount;
        String txId = "";
    }

    private record Match(String txId, long amount) {}

    private record Tx(String id, long amount, String text) {}

    private static class CardOrder {
        String requestId;
        UUID uuid;
        String name;
        String telco;
        long declared;
        String serial = "";
        String code = "";
        long created;
        String status = PENDING;
        boolean sent = true;
        long value;
        long received;
    }

    private record CardSnap(String requestId, String telco, long declared, String serial, String code) {}

    private static class CardPrompt {
        String telco;
        long amount;
        String serial = "";
        boolean needCode = false;
        long created = System.currentTimeMillis();
    }

    /** Ve anh QR len ban do (chi ve 1 lan). */
    private static class QrRenderer extends MapRenderer {
        private final BufferedImage image;
        private boolean done = false;

        QrRenderer(BufferedImage image) {
            super(false);
            this.image = image;
        }

        @Override
        public void render(MapView map, MapCanvas canvas, Player player) {
            if (done) return;
            canvas.drawImage(0, 0, image);
            done = true;
        }
    }

    private final Map<String, Order> orders = new LinkedHashMap<>();
    private final Set<String> paidTx = new HashSet<>();
    private final Set<String> ignoredTx = new HashSet<>();
    private final AtomicBoolean polling = new AtomicBoolean(false);
    private final SecureRandom random = new SecureRandom();
    private final Set<String> warnedAuth = ConcurrentHashMap.newKeySet();
    private boolean warnedConfig = false;
    private File ordersFile;
    private NamespacedKey qrKey;
    private int taskId = -1;

    private final Map<String, CardOrder> cards = new LinkedHashMap<>();
    private final Map<UUID, CardPrompt> prompts = new ConcurrentHashMap<>();
    // Nguoi choi dang go so tien tuy y vao chat (uuid -> thoi diem bat dau)
    private final Map<UUID, Long> amountPrompts = new ConcurrentHashMap<>();
    private final AtomicBoolean cardPolling = new AtomicBoolean(false);
    private File cardsFile;
    private int cardTaskId = -1;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        ordersFile = new File(getDataFolder(), "orders.yml");
        qrKey = new NamespacedKey(this, "order");
        cardsFile = new File(getDataFolder(), "cards.yml");
        loadOrders();
        loadCards();
        getCommand("napbank").setExecutor(this);
        getCommand("napbank").setTabCompleter(this);
        getCommand("napthe").setExecutor(this);
        getCommand("napthe").setTabCompleter(this);
        Bukkit.getPluginManager().registerEvents(this, this);
        startPolling();
        getLogger().info("Coffeecat Bank da bat.");
    }

    @Override
    public void onDisable() {
        if (taskId != -1) Bukkit.getScheduler().cancelTask(taskId);
        if (cardTaskId != -1) Bukkit.getScheduler().cancelTask(cardTaskId);
        for (Player pl : Bukkit.getOnlinePlayers()) {
            if (pl.getOpenInventory().getTopInventory().getHolder() instanceof Gui) pl.closeInventory();
        }
        saveOrders();
        saveCards();
    }

    private static final List<String> PROVIDERS = List.of("sepay", "thueapibank", "rpay");

    private String pv(String name, String key, String def) {
        return getConfig().getString("providers." + name + "." + key, def);
    }

    private List<String> pvList(String name, String key) {
        return getConfig().getStringList("providers." + name + "." + key);
    }

    /** Nha cung cap dang BAT (enabled: true) va da dien url. */
    private List<String> activeProviders() {
        List<String> out = new ArrayList<>();
        for (String n : PROVIDERS) {
            if (getConfig().getBoolean("providers." + n + ".enabled", false) && !pv(n, "url", "").isBlank()) out.add(n);
        }
        return out;
    }

    private boolean bankEnabled() {
        return getConfig().getBoolean("bank.enabled", true);
    }

    private boolean cardEnabled() {
        return getConfig().getBoolean("card.enabled", true);
    }

    private boolean cardReady() {
        FileConfiguration c = getConfig();
        return cardEnabled()
                && !c.getString("card.partner-id", "").isBlank()
                && !c.getString("card.partner-key", "").isBlank();
    }

    /** Bao loi dung ly do cho nguoi choi: tat / chua cau hinh. Tra ve true neu dung duoc. */
    private boolean checkCard(Player p) {
        if (!cardEnabled()) { tell(p, "card-disabled", null); return false; }
        if (!cardReady()) { tell(p, "card-not-configured", null); return false; }
        return true;
    }

    private void startPolling() {
        if (taskId != -1) Bukkit.getScheduler().cancelTask(taskId);
        int secs = Math.max(10, getConfig().getInt("provider.poll-seconds", 15));
        taskId = Bukkit.getScheduler().runTaskTimer(this, this::pollTick, 100L, secs * 20L).getTaskId();
        if (cardTaskId != -1) Bukkit.getScheduler().cancelTask(cardTaskId);
        int cs = Math.max(10, getConfig().getInt("card.poll-seconds", 15));
        cardTaskId = Bukkit.getScheduler().runTaskTimer(this, this::cardTick, 140L, cs * 20L).getTaskId();
    }

    // ---------- Luu tru ----------

    private void loadOrders() {
        orders.clear();
        paidTx.clear();
        if (!ordersFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(ordersFile);
        ConfigurationSection s = y.getConfigurationSection("orders");
        if (s == null) return;
        for (String code : s.getKeys(false)) {
            ConfigurationSection c = s.getConfigurationSection(code);
            if (c == null) continue;
            try {
                Order o = new Order();
                o.code = code;
                o.uuid = UUID.fromString(c.getString("uuid", ""));
                o.name = c.getString("name", "?");
                o.amount = c.getLong("amount");
                o.created = c.getLong("created");
                o.status = c.getString("status", PENDING);
                o.paidAmount = c.getLong("paid-amount");
                o.txId = c.getString("tx-id", "");
                orders.put(code, o);
                if (PAID.equals(o.status) && !o.txId.isEmpty()) paidTx.add(o.txId);
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    private void saveOrders() {
        YamlConfiguration y = new YamlConfiguration();
        for (Order o : orders.values()) {
            String p = "orders." + o.code + ".";
            y.set(p + "uuid", o.uuid.toString());
            y.set(p + "name", o.name);
            y.set(p + "amount", o.amount);
            y.set(p + "created", o.created);
            y.set(p + "status", o.status);
            y.set(p + "paid-amount", o.paidAmount);
            y.set(p + "tx-id", o.txId);
        }
        try {
            y.save(ordersFile);
        } catch (IOException e) {
            getLogger().warning("Khong luu duoc orders.yml: " + e.getMessage());
        }
    }

    // ---------- Tin nhan ----------

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private String raw(String key) {
        return getConfig().getString("messages." + key, key);
    }

    private String fill(String s, Map<String, String> ph) {
        if (ph != null) for (Map.Entry<String, String> e : ph.entrySet()) s = s.replace("{" + e.getKey() + "}", e.getValue());
        return s;
    }

    private void tell(CommandSender to, String key, Map<String, String> ph) {
        to.sendMessage(color(raw("prefix") + fill(raw(key), ph)));
    }

    private void line(CommandSender to, String key, Map<String, String> ph) {
        to.sendMessage(color(fill(raw(key), ph)));
    }

    private String money(long v) {
        return String.format(Locale.US, "%,d", v).replace(',', '.');
    }

    // ---------- Lenh ----------

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("napthe")) {
            handleNapThe(sender, args);
            return true;
        }
        if (args.length == 0) {
            if (sender instanceof Player gp && gp.hasPermission("coffeecatbank.use")) openBankGui(gp);
            else tell(sender, "usage", null);
            return true;
        }
        String a = args[0].toLowerCase(Locale.ROOT);
        switch (a) {
            case "reload":
                if (!sender.hasPermission("coffeecatbank.admin")) { tell(sender, "no-permission", null); return true; }
                reloadConfig();
                warnedConfig = false;
                startPolling();
                tell(sender, "reloaded", null);
                return true;
            case "status":
                if (!sender.hasPermission("coffeecatbank.admin")) { tell(sender, "no-permission", null); return true; }
                sender.sendMessage(color("&6Nạp bank: " + (bankEnabled() ? "&aBẬT" : "&cTẮT")));
                for (String n : PROVIDERS) {
                    boolean on = getConfig().getBoolean("providers." + n + ".enabled", false);
                    boolean hasUrl = !pv(n, "url", "").isBlank();
                    sender.sendMessage(color("  &7- &f" + n + ": " + (on ? "&aBẬT" : "&cTẮT") + (on && !hasUrl ? " &e(thiếu url)" : "")));
                }
                sender.sendMessage(color("&6Nạp thẻ (Card2K): " + (cardEnabled() ? "&aBẬT" : "&cTẮT")
                        + (cardEnabled() && !cardReady() ? " &e(thiếu partner-id/key)" : "")));
                return true;
            case "pending":
                if (!sender.hasPermission("coffeecatbank.admin")) { tell(sender, "no-permission", null); return true; }
                int n = 0;
                for (Order o : orders.values()) {
                    if (!PENDING.equals(o.status)) continue;
                    n++;
                    sender.sendMessage(color("&6" + o.code + " &7- &f" + o.name + " &7- &e" + money(o.amount) + "đ"));
                }
                if (n == 0) sender.sendMessage(color("&7Không có lệnh nạp nào đang chờ."));
                return true;
            case "huy":
            case "cancel":
                if (!(sender instanceof Player)) { sender.sendMessage(raw("player-only")); return true; }
                cancelPending((Player) sender);
                return true;
            case "menu":
            case "gui":
                if (!(sender instanceof Player)) { sender.sendMessage(raw("player-only")); return true; }
                if (!sender.hasPermission("coffeecatbank.use")) { tell(sender, "no-permission", null); return true; }
                openBankGui((Player) sender);
                return true;
            default:
                break;
        }
        if (!(sender instanceof Player)) { sender.sendMessage(raw("player-only")); return true; }
        if (!sender.hasPermission("coffeecatbank.use")) { tell(sender, "no-permission", null); return true; }
        createOrder((Player) sender, args[0]);
        return true;
    }

    private boolean cancelPending(Player p) {
        Order mine = pendingOf(p.getUniqueId());
        if (mine == null) { tell(p, "no-pending", null); return false; }
        mine.status = CANCELLED;
        saveOrders();
        removeQrMaps(p);
        tell(p, "cancelled", null);
        return true;
    }

    private Order pendingOf(UUID id) {
        for (Order o : orders.values()) if (PENDING.equals(o.status) && o.uuid.equals(id)) return o;
        return null;
    }

    private long parseAmount(String s) {
        try {
            s = s.toLowerCase(Locale.ROOT).replace(".", "").replace(",", "").trim();
            long mul = 1;
            if (s.endsWith("k")) { mul = 1000; s = s.substring(0, s.length() - 1); }
            return Long.parseLong(s) * mul;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /** Co du dieu kien de TAO lenh nap moi (bank bat + co provider bat + co so tai khoan). */
    private boolean configured() {
        FileConfiguration c = getConfig();
        return bankEnabled()
                && !activeProviders().isEmpty()
                && !c.getString("bank.account-number", "").isBlank()
                && !c.getString("bank.bank-id", "").isBlank();
    }

    private boolean checkBank(CommandSender p) {
        if (!bankEnabled()) { tell(p, "bank-disabled", null); return false; }
        if (!configured()) { tell(p, "not-configured", null); return false; }
        return true;
    }

    private void createOrder(Player p, String input) {
        if (!checkBank(p)) return;

        Order existing = pendingOf(p.getUniqueId());
        if (existing != null) {
            tell(p, "order-exists", null);
            showInstructions(p, existing);
            return;
        }

        long amount = parseAmount(input);
        if (amount <= 0) { tell(p, "invalid-amount", null); return; }
        long min = getConfig().getLong("order.min-amount", 10000);
        long max = getConfig().getLong("order.max-amount", 5000000);
        if (amount < min || amount > max) {
            tell(p, "amount-range", Map.of("min", money(min), "max", money(max)));
            return;
        }

        Order o = new Order();
        o.code = newCode();
        o.uuid = p.getUniqueId();
        o.name = p.getName();
        o.amount = amount;
        o.created = System.currentTimeMillis();
        orders.put(o.code, o);
        saveOrders();

        tell(p, "order-created", Map.of("amount", money(amount)));
        showInstructions(p, o);
    }

    private String newCode() {
        String prefix = getConfig().getString("order.prefix", "CC").replaceAll("[^A-Za-z0-9]", "").toUpperCase(Locale.ROOT);
        while (true) {
            StringBuilder sb = new StringBuilder(prefix);
            for (int i = 0; i < 6; i++) sb.append(ALPHABET.charAt(random.nextInt(ALPHABET.length())));
            if (!orders.containsKey(sb.toString())) return sb.toString();
        }
    }

    private String qrUrl(Order o, String template) {
        FileConfiguration c = getConfig();
        return "https://img.vietqr.io/image/"
                + URLEncoder.encode(c.getString("bank.bank-id", ""), StandardCharsets.UTF_8) + "-"
                + URLEncoder.encode(c.getString("bank.account-number", ""), StandardCharsets.UTF_8)
                + "-" + template + ".png?amount=" + o.amount
                + "&addInfo=" + URLEncoder.encode(o.code, StandardCharsets.UTF_8)
                + "&accountName=" + URLEncoder.encode(c.getString("bank.account-name", ""), StandardCharsets.UTF_8);
    }

    private void showInstructions(Player p, Order o) {
        FileConfiguration c = getConfig();
        long left = Math.max(1, c.getLong("order.expire-minutes", 30) - (System.currentTimeMillis() - o.created) / 60000L);
        Map<String, String> ph = Map.of(
                "bank", c.getString("bank.bank-display-name", c.getString("bank.bank-id", "")),
                "account", c.getString("bank.account-number", ""),
                "name", c.getString("bank.account-name", ""),
                "amount", money(o.amount),
                "code", o.code,
                "minutes", String.valueOf(left));
        line(p, "info-bank", ph);
        line(p, "info-account", ph);
        if (!c.getString("bank.account-name", "").isBlank()) line(p, "info-name", ph);
        line(p, "info-amount", ph);
        line(p, "info-content", ph);
        line(p, "info-expire", ph);
        line(p, "auto-note", ph);

        if (c.getBoolean("order.give-qr-map", true)) giveQrMap(p, o);

        try {
            p.sendMessage(Component.text(raw("qr-link"), NamedTextColor.AQUA, TextDecoration.UNDERLINED)
                    .clickEvent(ClickEvent.openUrl(qrUrl(o, "compact2"))));
        } catch (Exception ignored) {
        }
    }

    // ---------- Ma QR tren ban do ----------

    private void giveQrMap(Player p, Order o) {
        // Neu da co ban do cua lenh nay thi khong tao them
        if (hasQrMap(p, o.code)) return;
        final UUID id = p.getUniqueId();
        final String url = qrUrl(o, "qr_only");
        final String bin = QrMatrix.bankBin(getConfig().getString("bank.bank-id", ""));
        final String account = getConfig().getString("bank.account-number", "");
        final boolean useLocal = getConfig().getBoolean("order.qr-local", true);
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            BufferedImage scaled = null;

            // 1) Tu ve ma VietQR ngay trong server (khong can mang, khong phu thuoc img.vietqr.io)
            if (useLocal && bin != null && !account.isBlank()) {
                try {
                    scaled = QrMatrix.encode(QrMatrix.vietQrPayload(bin, account, o.amount, o.code)).toImage(128);
                } catch (Throwable t) {
                    getLogger().warning("Khong tu ve duoc ma QR, thu tai online: " + t);
                }
            }

            // 2) Du phong: tai anh QR tu img.vietqr.io
            if (scaled == null) {
                try {
                    HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
                    con.setConnectTimeout(8000);
                    con.setReadTimeout(8000);
                    con.setInstanceFollowRedirects(true);
                    con.setRequestProperty("User-Agent", "Mozilla/5.0 (compatible; CoffeecatBank)");
                    try {
                        int rc = con.getResponseCode();
                        if (rc != 200) {
                            getLogger().warning("Tai anh QR that bai, ma HTTP " + rc);
                        } else {
                            try (InputStream in = con.getInputStream()) {
                                BufferedImage src = ImageIO.read(in);
                                if (src != null) {
                                    scaled = new BufferedImage(128, 128, BufferedImage.TYPE_INT_RGB);
                                    Graphics2D g = scaled.createGraphics();
                                    g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
                                    g.setColor(java.awt.Color.WHITE);
                                    g.fillRect(0, 0, 128, 128);
                                    g.drawImage(src, 0, 0, 128, 128, null);
                                    g.dispose();
                                } else {
                                    getLogger().warning("Tai anh QR: khong doc duoc file anh tra ve.");
                                }
                            }
                        }
                    } finally {
                        con.disconnect();
                    }
                } catch (Throwable t) {
                    getLogger().warning("Khong tai duoc anh QR: " + t);
                }
            }
            final BufferedImage img = scaled;
            Bukkit.getScheduler().runTask(this, () -> {
                Player pl = Bukkit.getPlayer(id);
                if (pl == null || !PENDING.equals(o.status)) return;
                if (img == null) { tell(pl, "qr-failed", null); return; }
                try {
                    MapView view = Bukkit.createMap(pl.getWorld());
                    for (MapRenderer r : new ArrayList<>(view.getRenderers())) view.removeRenderer(r);
                    view.addRenderer(new QrRenderer(img));

                    ItemStack item = new ItemStack(Material.FILLED_MAP);
                    MapMeta meta = (MapMeta) item.getItemMeta();
                    meta.setMapView(view);
                    meta.displayName(Component.text("Mã QR nạp " + money(o.amount) + "đ", NamedTextColor.GOLD)
                            .decoration(TextDecoration.ITALIC, false));
                    meta.lore(List.of(
                            Component.text("Nội dung CK: " + o.code, NamedTextColor.YELLOW).decoration(TextDecoration.ITALIC, false),
                            Component.text("Cầm lên tay và quét bằng app ngân hàng", NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)));
                    meta.getPersistentDataContainer().set(qrKey, PersistentDataType.STRING, o.code);
                    item.setItemMeta(meta);

                    Map<Integer, ItemStack> left = pl.getInventory().addItem(item);
                    if (left.isEmpty()) {
                        tell(pl, "qr-given", null);
                    } else {
                        tell(pl, "inventory-full", Map.of("amount", String.valueOf(o.amount)));
                    }
                } catch (Throwable t) {
                    getLogger().log(java.util.logging.Level.WARNING, "Khong tao duoc ban do QR", t);
                    tell(pl, "qr-failed", null);
                }
            });
        });
    }

    private String qrCodeOf(ItemStack it) {
        if (it == null || it.getType() != Material.FILLED_MAP || !it.hasItemMeta()) return null;
        ItemMeta m = it.getItemMeta();
        return m.getPersistentDataContainer().get(qrKey, PersistentDataType.STRING);
    }

    private boolean hasQrMap(Player p, String code) {
        for (ItemStack it : p.getInventory().getContents()) {
            if (code.equals(qrCodeOf(it))) return true;
        }
        return false;
    }

    /** Xoa cac ban do QR cua lenh khong con cho thanh toan khoi tui do. */
    private void removeQrMaps(Player p) {
        ItemStack[] contents = p.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            String code = qrCodeOf(contents[i]);
            if (code == null) continue;
            Order o = orders.get(code);
            if (o == null || !PENDING.equals(o.status)) p.getInventory().setItem(i, null);
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        removeQrMaps(e.getPlayer());
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (qrCodeOf(e.getItemDrop().getItemStack()) != null) e.setCancelled(true);
    }

    // ---------- Kiem tra giao dich ----------

    private void pollTick() {
        if (polling.get()) return;
        long expireMs = getConfig().getLong("order.expire-minutes", 30) * 60000L;
        long now = System.currentTimeMillis();
        List<String> codes = new ArrayList<>();
        boolean changed = false;
        for (Order o : orders.values()) {
            if (!PENDING.equals(o.status)) continue;
            if (now - o.created > expireMs) {
                o.status = EXPIRED;
                changed = true;
                Player pl = Bukkit.getPlayer(o.uuid);
                if (pl != null) {
                    tell(pl, "expired", Map.of("code", o.code));
                    removeQrMaps(pl);
                }
            } else {
                codes.add(o.code);
            }
        }
        if (changed) saveOrders();
        if (codes.isEmpty()) return;
        final List<String> active = activeProviders();
        if (active.isEmpty()) {
            if (!warnedConfig) {
                warnedConfig = true;
                getLogger().warning("Khong co nha cung cap bank nao bat (providers.<ten>.enabled: true + url), chua kiem tra giao dich duoc.");
            }
            return;
        }

        polling.set(true);
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            List<Tx> txs = new ArrayList<>();
            boolean any = false;
            for (String name : active) {
                try {
                    List<Tx> part = fetch(name);
                    if (part != null) { txs.addAll(part); any = true; }
                } catch (Exception e) {
                    getLogger().warning("Loi goi API " + name + " (" + e.getClass().getSimpleName() + ")");
                }
            }
            final List<Tx> result = any ? txs : null;
            Bukkit.getScheduler().runTask(this, () -> {
                try {
                    if (result == null) return;
                    for (String code : codes) {
                        for (Tx t : result) {
                            if (paidTx.contains(t.id())) continue;
                            if (t.text().contains(code)) {
                                complete(code, new Match(t.id(), t.amount()));
                                break;
                            }
                        }
                    }
                } finally {
                    polling.set(false);
                }
            });
        });
    }

    private List<Tx> fetch(String name) throws IOException {
        FileConfiguration c = getConfig();
        String token = pv(name, "token", "");
        String method = pv(name, "method", "GET").toUpperCase(Locale.ROOT);
        String url = pv(name, "url", "").replace("{token}", URLEncoder.encode(token, StandardCharsets.UTF_8));

        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        try {
            con.setRequestMethod(method);
            con.setRequestProperty("Accept", "application/json");
            con.setRequestProperty("User-Agent", "CoffeecatBank");
            for (String h : pvList(name, "headers")) {
                int i = h.indexOf(':');
                if (i <= 0) continue;
                con.setRequestProperty(h.substring(0, i).trim(), h.substring(i + 1).trim().replace("{token}", token));
            }
            con.setConnectTimeout(8000);
            con.setReadTimeout(8000);
            if (method.equals("POST")) {
                con.setDoOutput(true);
                con.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                String body = pv(name, "body", "").replace("{token}", token);
                try (OutputStream os = con.getOutputStream()) {
                    os.write(body.getBytes(StandardCharsets.UTF_8));
                }
            }
            int rc = con.getResponseCode();
            if (rc == 401 || rc == 403) {
                if (warnedAuth.add(name)) {
                    getLogger().warning(name + " tra ve " + rc + ": token sai hoac khong du quyen.");
                }
                return null;
            }
            if (rc >= 300) {
                if (rc != 429) getLogger().warning(name + " tra ve ma " + rc);
                return null;
            }
            warnedAuth.remove(name);
            String bodyText = new String(con.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
            return parse(name, JsonParser.parseString(bodyText));
        } finally {
            con.disconnect();
        }
    }

    private List<Tx> parse(String name, JsonElement root) {
        FileConfiguration c = getConfig();
        String fId = pv(name, "fields.id", "id");
        String fAmount = pv(name, "fields.amount", "amount");
        String fContent = pv(name, "fields.content", "description");
        String fType = pv(name, "fields.type", "");
        String typeIn = pv(name, "fields.type-in-value", "in");

        List<Tx> out = new ArrayList<>();
        for (JsonElement el : listOf(root, pv(name, "fields.list-path", ""))) {
            if (!el.isJsonObject()) continue;
            JsonObject t = el.getAsJsonObject();
            if (!fType.isBlank() && !typeIn.equalsIgnoreCase(str(t, fType))) continue;

            Long amount = amountOf(t.get(fAmount));
            if (amount == null || amount <= 0) continue;

            String text = (str(t, fContent) + " " + t.toString()).toUpperCase(Locale.ROOT);
            String id = str(t, fId);
            if (id.isEmpty()) id = "h" + Integer.toHexString(t.toString().hashCode());
            out.add(new Tx(name + ":" + id, amount, text));
        }
        return out;
    }

    private JsonArray listOf(JsonElement root, String path) {
        JsonElement cur = root;
        if (!path.isBlank()) {
            for (String k : path.split("\\.")) {
                if (cur == null || !cur.isJsonObject()) { cur = null; break; }
                cur = cur.getAsJsonObject().get(k.trim());
            }
        }
        return cur != null && cur.isJsonArray() ? cur.getAsJsonArray() : new JsonArray();
    }

    private Long amountOf(JsonElement e) {
        if (e == null || e.isJsonNull()) return null;
        String s = e.getAsString().trim().replace(",", "");
        try {
            return (long) Double.parseDouble(s);
        } catch (NumberFormatException ex) {
            try {
                return (long) Double.parseDouble(s.replace(".", ""));
            } catch (NumberFormatException ex2) {
                return null;
            }
        }
    }

    private String str(JsonObject o, String key) {
        JsonElement e = o.get(key);
        return e == null || e.isJsonNull() || !e.isJsonPrimitive() ? "" : e.getAsString();
    }

    // Chay tren main thread
    private void complete(String code, Match m) {
        Order o = orders.get(code);
        if (o == null || !PENDING.equals(o.status)) return;
        if (paidTx.contains(m.txId())) return;

        long min = getConfig().getLong("order.min-amount", 10000);
        if (m.amount() < min) {
            if (ignoredTx.add(m.txId())) {
                getLogger().warning("Giao dich " + m.txId() + " (" + m.amount() + "d) cho ma " + code + " duoi muc toi thieu, bo qua.");
            }
            return;
        }

        // Ghi nhan truoc khi thuong de tranh thuong 2 lan
        o.status = PAID;
        o.paidAmount = m.amount();
        o.txId = m.txId();
        paidTx.add(m.txId());
        saveOrders();

        double rate = getConfig().getDouble("reward.money-rate", 1.0);
        long moneyAmount = Math.max(1, Math.round(m.amount() * rate));
        for (String command : getConfig().getStringList("reward.commands")) {
            String cmd = command
                    .replace("%player%", o.name)
                    .replace("%amount%", String.valueOf(m.amount()))
                    .replace("%money%", String.valueOf(moneyAmount))
                    .replace("%points%", String.valueOf(moneyAmount));
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
        }
        getLogger().info("Nap thanh cong: " + o.name + " " + m.amount() + "d (" + moneyAmount + " tien game), ma " + code + ", giao dich " + m.txId());

        Player pl = Bukkit.getPlayer(o.uuid);
        if (pl != null) {
            removeQrMaps(pl);
            tell(pl, "success", Map.of("amount", money(m.amount()), "money", money(moneyAmount)));
        }
        sendWebhook(o.name, m.amount());
    }

    private void sendWebhook(String player, long amount) {
        notifyAll(fill(raw("discord-text"), Map.of("player", player, "amount", money(amount))));
    }

    /**
     * Gui thong bao len Discord (webhook) va Telegram (bot) cung luc.
     * Noi nao de trong cau hinh thi bo qua noi do. Text dung **dam** kieu Discord,
     * voi Telegram se tu doi sang <b>dam</b>.
     */
    private void notifyAll(String text) {
        FileConfiguration c = getConfig();
        String discordUrl = c.getString("reward.discord-webhook-url", "");
        String tgToken = c.getString("reward.telegram.bot-token", "").trim();
        String tgChat = c.getString("reward.telegram.chat-id", "").trim();
        int tgThread = c.getInt("reward.telegram.thread-id", 0);
        boolean tg = !tgToken.isBlank() && !tgChat.isBlank();
        if (discordUrl.isBlank() && !tg) return;

        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            if (!discordUrl.isBlank()) {
                String json = "{\"username\":\"Coffeecat Bank\",\"content\":\"" + esc(text) + "\"}";
                postJson(discordUrl, json, "Discord");
            }
            if (tg) {
                String html = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                        .replaceAll("\\*\\*(.+?)\\*\\*", "<b>$1</b>");
                String json = "{\"chat_id\":\"" + esc(tgChat) + "\","
                        + (tgThread > 0 ? "\"message_thread_id\":" + tgThread + "," : "")
                        + "\"parse_mode\":\"HTML\",\"disable_web_page_preview\":true,"
                        + "\"text\":\"" + esc(html) + "\"}";
                postJson("https://api.telegram.org/bot" + tgToken + "/sendMessage", json, "Telegram");
            }
        });
    }

    // Chay tren thread async. Khong in URL ra log vi URL webhook / token bot la bi mat.
    private void postJson(String url, String json, String label) {
        try {
            HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            con.setRequestProperty("User-Agent", "CoffeecatBank");
            con.setConnectTimeout(5000);
            con.setReadTimeout(5000);
            con.setDoOutput(true);
            try (OutputStream os = con.getOutputStream()) {
                os.write(json.getBytes(StandardCharsets.UTF_8));
            }
            int rc = con.getResponseCode();
            if (rc >= 400) getLogger().warning("Gui thong bao " + label + " that bai, ma HTTP " + rc);
            con.disconnect();
        } catch (Exception e) {
            getLogger().warning("Gui thong bao " + label + " loi: " + e.getClass().getSimpleName());
        }
    }

    private String esc(String s) {
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toCharArray()) {
            switch (ch) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': break;
                default: sb.append(ch);
            }
        }
        return sb.toString();
    }

    // ================= NAP THE CAO (Card2K) =================

    private void loadCards() {
        cards.clear();
        if (!cardsFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(cardsFile);
        ConfigurationSection sec = y.getConfigurationSection("cards");
        if (sec == null) return;
        for (String id : sec.getKeys(false)) {
            ConfigurationSection c = sec.getConfigurationSection(id);
            if (c == null) continue;
            try {
                CardOrder o = new CardOrder();
                o.requestId = id;
                o.uuid = UUID.fromString(c.getString("uuid", ""));
                o.name = c.getString("name", "?");
                o.telco = c.getString("telco", "");
                o.declared = c.getLong("declared");
                o.serial = c.getString("serial", "");
                o.code = c.getString("code", "");
                o.created = c.getLong("created");
                o.status = c.getString("status", PENDING);
                o.value = c.getLong("value");
                o.received = c.getLong("received");
                cards.put(id, o);
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    private void saveCards() {
        YamlConfiguration y = new YamlConfiguration();
        for (CardOrder o : cards.values()) {
            String p = "cards." + o.requestId + ".";
            y.set(p + "uuid", o.uuid.toString());
            y.set(p + "name", o.name);
            y.set(p + "telco", o.telco);
            y.set(p + "declared", o.declared);
            y.set(p + "serial", o.serial);
            y.set(p + "code", o.code);
            y.set(p + "created", o.created);
            y.set(p + "status", o.status);
            y.set(p + "value", o.value);
            y.set(p + "received", o.received);
        }
        try {
            y.save(cardsFile);
        } catch (IOException e) {
            getLogger().warning("Khong luu duoc cards.yml: " + e.getMessage());
        }
    }

    private void handleNapThe(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(raw("player-only"));
            return;
        }
        if (!p.hasPermission("coffeecatbank.use")) { tell(p, "no-permission", null); return; }
        if (args.length >= 1 && (args[0].equalsIgnoreCase("huy") || args[0].equalsIgnoreCase("cancel"))) {
            if (prompts.remove(p.getUniqueId()) != null) tell(p, "card-prompt-cancelled", null);
            else tell(p, "no-pending", null);
            return;
        }
        if (!checkCard(p)) return;
        // /napthe  -> mo giao dien chon nha mang
        if (args.length == 0) {
            openTelcoGui(p);
            return;
        }
        // /napthe <nha mang>  -> mo giao dien chon menh gia
        if (args.length == 1) {
            String t = args[0].toUpperCase(Locale.ROOT);
            if (!cardTelcos().contains(t)) {
                tell(p, "card-bad-telco", Map.of("telcos", String.join(", ", cardTelcos())));
                return;
            }
            openCardAmountGui(p, t);
            return;
        }
        // /napthe <nha mang> <menh gia>  -> nhap thang
        startCardPrompt(p, args[0].toUpperCase(Locale.ROOT), parseAmount(args[1]));
    }

    private List<String> cardTelcos() {
        ConfigurationSection sec = getConfig().getConfigurationSection("card.telcos");
        if (sec != null) { // dang map: TEN: true/false
            List<String> out = new ArrayList<>();
            for (String k : sec.getKeys(false)) if (sec.getBoolean(k, false)) out.add(k.toUpperCase(Locale.ROOT));
            return out;
        }
        return getConfig().getStringList("card.telcos").stream() // dang list cu
                .map(x -> x.toUpperCase(Locale.ROOT)).collect(Collectors.toList());
    }

    /** Mệnh giá cho từng nhà mạng: ưu tiên card.amounts-by-telco.<NHA MANG>, không có thì dùng card.amounts chung. */
    private List<Long> cardAmounts(String telco) {
        FileConfiguration c = getConfig();
        ConfigurationSection sec = c.getConfigurationSection("card.amounts-by-telco");
        if (sec != null && telco != null) {
            for (String k : sec.getKeys(false)) {
                if (k.equalsIgnoreCase(telco)) {
                    List<Long> l = sec.getLongList(k);
                    if (!l.isEmpty()) return l;
                }
            }
        }
        return c.getLongList("card.amounts");
    }

    /** Kiem tra hop le roi bat dau buoc nhap serial / ma the qua chat. */
    private void startCardPrompt(Player p, String telco, long amount) {
        FileConfiguration c = getConfig();
        if (!checkCard(p)) return;
        String telcoText = String.join(", ", cardTelcos());
        String amountText = cardAmounts(telco).stream().map(this::money).collect(Collectors.joining(", "));
        if (!cardTelcos().contains(telco)) {
            tell(p, "card-bad-telco", Map.of("telcos", telcoText));
            return;
        }
        if (!cardAmounts(telco).contains(amount)) {
            tell(p, "card-bad-amount", Map.of("amounts", amountText));
            return;
        }
        int max = c.getInt("card.max-pending-per-player", 3);
        int count = 0;
        for (CardOrder o : cards.values()) if (PENDING.equals(o.status) && o.uuid.equals(p.getUniqueId())) count++;
        if (count >= max) {
            tell(p, "card-too-many", Map.of("max", String.valueOf(max)));
            return;
        }

        CardPrompt pr = new CardPrompt();
        pr.telco = telco;
        pr.amount = amount;
        prompts.put(p.getUniqueId(), pr);
        tell(p, "card-prompt-serial", Map.of("telco", telco, "amount", money(amount),
                "seconds", String.valueOf(c.getInt("card.prompt-seconds", 60))));
        showPromptTitle(p, "card-title-serial");
    }

    private void showPromptTitle(Player p, String titleKey) {
        if (!getConfig().getBoolean("gui.title-prompts", true)) return;
        LegacyComponentSerializer ser = LegacyComponentSerializer.legacyAmpersand();
        p.showTitle(Title.title(ser.deserialize(raw(titleKey)), ser.deserialize(raw("prompt-subtitle")),
                Title.Times.times(Duration.ofMillis(150), Duration.ofSeconds(5), Duration.ofMillis(400))));
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        if (prompts.containsKey(id)) {
            // Chan tin nhan de nguoi khac va log khong thay so serial / ma the
            e.setCancelled(true);
            String text = PlainTextComponentSerializer.plainText().serialize(e.message()).trim();
            Bukkit.getScheduler().runTask(this, () -> handlePrompt(p, text));
            return;
        }
        Long since = amountPrompts.get(id);
        if (since != null) {
            long promptMs = getConfig().getLong("card.prompt-seconds", 60) * 1000L;
            if (System.currentTimeMillis() - since > promptMs) {
                amountPrompts.remove(id);
                return; // het han: de tin nhan di nhu chat binh thuong
            }
            e.setCancelled(true);
            String text = PlainTextComponentSerializer.plainText().serialize(e.message()).trim();
            Bukkit.getScheduler().runTask(this, () -> handleAmountPrompt(p, text));
        }
    }

    private void handleAmountPrompt(Player p, String text) {
        if (amountPrompts.remove(p.getUniqueId()) == null) return;
        if (text.equalsIgnoreCase("huy") || text.equalsIgnoreCase("cancel")) {
            tell(p, "gui-custom-cancelled", null);
            return;
        }
        createOrder(p, text);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        prompts.remove(e.getPlayer().getUniqueId());
        amountPrompts.remove(e.getPlayer().getUniqueId());
    }

    private void handlePrompt(Player p, String text) {
        CardPrompt pr = prompts.get(p.getUniqueId());
        if (pr == null) return;
        long promptMs = getConfig().getLong("card.prompt-seconds", 60) * 1000L;
        if (System.currentTimeMillis() - pr.created > promptMs) {
            prompts.remove(p.getUniqueId());
            tell(p, "card-prompt-expired", null);
            return;
        }
        if (text.equalsIgnoreCase("huy") || text.equalsIgnoreCase("cancel")) {
            prompts.remove(p.getUniqueId());
            tell(p, "card-prompt-cancelled", null);
            return;
        }
        if (!text.matches("[A-Za-z0-9]{6,32}")) {
            tell(p, "card-invalid-input", null);
            return;
        }
        if (!pr.needCode) {
            pr.serial = text;
            pr.needCode = true;
            pr.created = System.currentTimeMillis();
            tell(p, "card-prompt-code", null);
            showPromptTitle(p, "card-title-code");
            return;
        }
        prompts.remove(p.getUniqueId());
        submitCard(p, pr, text);
    }

    private String newRequestId() {
        while (true) {
            StringBuilder sb = new StringBuilder("CC");
            for (int i = 0; i < 12; i++) sb.append(ALPHABET.charAt(random.nextInt(ALPHABET.length())));
            if (!cards.containsKey(sb.toString())) return sb.toString();
        }
    }

    private void submitCard(Player p, CardPrompt pr, String code) {
        CardOrder co = new CardOrder();
        co.requestId = newRequestId();
        co.uuid = p.getUniqueId();
        co.name = p.getName();
        co.telco = pr.telco;
        co.declared = pr.amount;
        co.serial = pr.serial;
        co.code = code;
        co.created = System.currentTimeMillis();
        co.sent = false;
        // Luu truoc khi gui de khong bi mat dau vet neu server tat giua chung
        cards.put(co.requestId, co);
        saveCards();

        tell(p, "card-submitting", Map.of("telco", co.telco, "amount", money(co.declared)));
        final CardSnap snap = new CardSnap(co.requestId, co.telco, co.declared, co.serial, co.code);
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            JsonObject r = null;
            try {
                r = cardCall("charging", snap);
            } catch (Exception e) {
                getLogger().warning("Loi gui the " + snap.requestId() + " (" + e.getClass().getSimpleName() + ")");
            }
            final JsonObject fr = r;
            Bukkit.getScheduler().runTask(this, () -> {
                CardOrder cur = cards.get(snap.requestId());
                if (cur != null) cur.sent = true;
                handleCardResult(snap.requestId(), fr, true);
            });
        });
    }

    private String md5(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            StringBuilder sb = new StringBuilder();
            for (byte b : md.digest(s.getBytes(StandardCharsets.UTF_8))) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    private String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }

    /** Goi API Card2K (mục 1): command la "charging" (gui the) hoac "check" (tra the). */
    private JsonObject cardCall(String command, CardSnap s) throws IOException {
        FileConfiguration c = getConfig();
        String key = c.getString("card.partner-key", "");
        String body = "command=" + enc(command)
                + "&telco=" + enc(s.telco())
                + "&code=" + enc(s.code())
                + "&serial=" + enc(s.serial())
                + "&amount=" + s.declared()
                + "&request_id=" + enc(s.requestId())
                + "&partner_id=" + enc(c.getString("card.partner-id", ""))
                + "&sign=" + md5(key + s.code() + s.serial());

        HttpURLConnection con = (HttpURLConnection) new URL(c.getString("card.api-url", "https://card2k.net/chargingws/v2")).openConnection();
        try {
            con.setRequestMethod("POST");
            con.setRequestProperty("Accept", "application/json");
            con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            con.setRequestProperty("User-Agent", "CoffeecatBank");
            con.setConnectTimeout(10000);
            con.setReadTimeout(15000);
            con.setDoOutput(true);
            try (OutputStream os = con.getOutputStream()) {
                os.write(body.getBytes(StandardCharsets.UTF_8));
            }
            int rc = con.getResponseCode();
            if (rc == 429 || rc >= 500) {
                getLogger().warning("Card2K tra ve ma " + rc + ", se thu lai sau.");
                return null;
            }
            InputStream in = rc >= 400 ? con.getErrorStream() : con.getInputStream();
            if (in == null) return null;
            String text = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            JsonElement el = JsonParser.parseString(text);
            return el.isJsonObject() ? el.getAsJsonObject() : null;
        } finally {
            con.disconnect();
        }
    }

    private int intOf(JsonObject o, String key, int def) {
        JsonElement e = o.get(key);
        if (e == null || e.isJsonNull() || !e.isJsonPrimitive()) return def;
        try {
            return (int) Double.parseDouble(e.getAsString());
        } catch (NumberFormatException ex) {
            return def;
        }
    }

    private void cardTick() {
        long promptMs = getConfig().getLong("card.prompt-seconds", 60) * 1000L;
        long now = System.currentTimeMillis();
        for (Map.Entry<UUID, CardPrompt> en : new ArrayList<>(prompts.entrySet())) {
            if (now - en.getValue().created > promptMs && prompts.remove(en.getKey(), en.getValue())) {
                Player pl = Bukkit.getPlayer(en.getKey());
                if (pl != null) tell(pl, "card-prompt-expired", null);
            }
        }
        if (cardPolling.get()) return;
        if (getConfig().getString("card.partner-id", "").isBlank()) return;

        List<CardSnap> snaps = new ArrayList<>();
        for (CardOrder o : cards.values()) {
            if (PENDING.equals(o.status) && o.sent && !o.code.isEmpty()) {
                snaps.add(new CardSnap(o.requestId, o.telco, o.declared, o.serial, o.code));
            }
        }
        if (snaps.isEmpty()) return;

        cardPolling.set(true);
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            Map<String, JsonObject> results = new LinkedHashMap<>();
            try {
                for (CardSnap sn : snaps) {
                    try {
                        JsonObject r = cardCall("check", sn);
                        if (r != null) results.put(sn.requestId(), r);
                    } catch (IOException e) {
                        getLogger().warning("Loi tra the " + sn.requestId() + " (" + e.getClass().getSimpleName() + ")");
                    }
                    Thread.sleep(400);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            Bukkit.getScheduler().runTask(this, () -> {
                try {
                    for (Map.Entry<String, JsonObject> en : results.entrySet()) {
                        handleCardResult(en.getKey(), en.getValue(), false);
                    }
                } finally {
                    cardPolling.set(false);
                }
            });
        });
    }

    // Chay tren main thread
    private void handleCardResult(String id, JsonObject r, boolean fromSubmit) {
        CardOrder co = cards.get(id);
        if (co == null || !PENDING.equals(co.status)) return;
        Player pl = Bukkit.getPlayer(co.uuid);
        if (r == null) {
            if (fromSubmit && pl != null) tell(pl, "card-network", null);
            return; // giu o trang thai cho, lan tra the sau se quyet dinh
        }
        int st = intOf(r, "status", -1);
        String msg = str(r, "message");
        switch (st) {
            case 99:
                if (fromSubmit && pl != null) tell(pl, "card-received", null);
                return;
            case 4:
                if (fromSubmit) failCard(co, "Hệ thống thẻ đang bảo trì, hãy thử lại sau");
                return;
            case 1:
                finishCard(co, true, intOf(r, "value", 0), intOf(r, "amount", 0));
                return;
            case 2:
                finishCard(co, false, intOf(r, "value", 0), intOf(r, "amount", 0));
                return;
            default:
                failCard(co, msg.isBlank() ? "Thẻ không hợp lệ" : msg);
        }
    }

    private void failCard(CardOrder co, String reason) {
        co.status = FAILED;
        co.serial = "";
        co.code = "";
        saveCards();
        getLogger().info("The loi: " + co.name + " " + co.telco + " " + co.declared + "d, ma " + co.requestId);
        Player pl = Bukkit.getPlayer(co.uuid);
        if (pl != null) tell(pl, "card-failed", Map.of("reason", reason));
    }

    private void finishCard(CardOrder co, boolean exact, long value, long received) {
        FileConfiguration c = getConfig();
        long base;
        if (exact) {
            base = value > 0 ? value : co.declared;
        } else if ("received".equalsIgnoreCase(c.getString("card.wrong-amount-reward", "received"))) {
            // Sai mệnh giá: trừ thêm wrong-amount-penalty (mặc định 50%) trên số tiền được tính
            double penalty = Math.min(1.0, Math.max(0.0, c.getDouble("card.wrong-amount-penalty", 0.5)));
            base = Math.round(received * (1.0 - penalty));
        } else {
            base = 0;
        }
        if (base <= 0) {
            failCard(co, "Thẻ sai mệnh giá nên không được cộng tiền");
            return;
        }

        // Ghi nhan truoc khi thuong de tranh thuong 2 lan; xoa so serial/ma the khoi file
        co.status = DONE;
        co.value = value;
        co.received = received;
        co.serial = "";
        co.code = "";
        saveCards();

        long penaltyPercent = exact ? 0
                : Math.round(Math.min(1.0, Math.max(0.0, c.getDouble("card.wrong-amount-penalty", 0.5))) * 100);
        long moneyAmount = Math.max(1, Math.round(base * c.getDouble("card.money-rate", 1.0)));
        for (String command : c.getStringList("card.commands")) {
            String cmd = command
                    .replace("%player%", co.name)
                    .replace("%amount%", String.valueOf(base))
                    .replace("%declared%", String.valueOf(co.declared))
                    .replace("%money%", String.valueOf(moneyAmount))
                    .replace("%points%", String.valueOf(moneyAmount));
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
        }
        getLogger().info("Nap the thanh cong: " + co.name + " " + co.telco + " menh gia " + co.declared
                + "d, tinh " + base + "d (" + moneyAmount + " tien game), ma " + co.requestId);

        Player pl = Bukkit.getPlayer(co.uuid);
        if (pl != null) {
            String key = exact ? "card-success" : "card-wrong-amount";
            tell(pl, key, Map.of("amount", money(base), "money", money(moneyAmount), "declared", money(co.declared),
                    "penalty", String.valueOf(penaltyPercent)));
        }
        if (exact) sendCardWebhook(co.name, base);
        else sendCardWrongWebhook(co, base, value, penaltyPercent);
    }

    private void sendCardWebhook(String player, long amount) {
        notifyAll(fill(raw("discord-card-text"), Map.of("player", player, "amount", money(amount))));
    }

    private void sendCardWrongWebhook(CardOrder co, long base, long value, long penaltyPercent) {
        notifyAll(fill(raw("discord-card-wrong-text"), Map.of(
                "player", co.name,
                "telco", co.telco,
                "declared", money(co.declared),
                "value", value > 0 ? money(value) : "?",
                "penalty", String.valueOf(penaltyPercent),
                "amount", money(base))));
    }

    // ================= GIAO DIEN (GUI) =================

    private static class Gui implements InventoryHolder {
        Inventory inv;
        boolean used = false;
        final Map<Integer, Consumer<Player>> actions = new HashMap<>();

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private static final Material[] TIERS = {
            Material.COPPER_INGOT, Material.IRON_INGOT, Material.GOLD_INGOT, Material.EMERALD,
            Material.DIAMOND, Material.NETHERITE_INGOT, Material.NETHER_STAR, Material.BEACON};

    private String g(String key, String def) {
        return getConfig().getString("gui." + key, def);
    }

    private Component lc(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s).decoration(TextDecoration.ITALIC, false);
    }

    private ItemStack icon(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(lc(name));
        if (lore.length > 0) {
            List<Component> l = new ArrayList<>();
            for (String s : lore) l.add(lc(s));
            meta.lore(l);
        }
        it.setItemMeta(meta);
        return it;
    }

    private int guiRows(int n) {
        return Math.max(1, Math.min(4, (n + 6) / 7));
    }

    private int guiSize(int n) {
        return (guiRows(n) + 2) * 9;
    }

    private Gui newGui(String title, int size) {
        Gui gui = new Gui();
        gui.inv = Bukkit.createInventory(gui, size, LegacyComponentSerializer.legacyAmpersand().deserialize(title));
        ItemStack pane = icon(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < size; i++) gui.inv.setItem(i, pane);
        return gui;
    }

    private void put(Gui gui, int slot, ItemStack item, Consumer<Player> action) {
        gui.inv.setItem(slot, item);
        if (action != null) gui.actions.put(slot, action);
        else gui.actions.remove(slot);
    }

    /** Xep n o vao giua cac hang (cot 1-7, hang 1 tro di). */
    private int[] layout(int n) {
        int rows = guiRows(n);
        int[] out = new int[n];
        int idx = 0;
        for (int r = 0; r < rows; r++) {
            int k = n / rows + (r < n % rows ? 1 : 0);
            int start = 1 + (7 - k) / 2;
            for (int i = 0; i < k; i++) out[idx++] = 9 * (r + 1) + start + i;
        }
        return out;
    }

    private Material tier(int i, int n) {
        return TIERS[Math.min(TIERS.length - 1, i * TIERS.length / Math.max(1, n))];
    }

    private void clickSound(Player p) {
        if (getConfig().getBoolean("gui.sound", true)) {
            p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.2f);
        }
    }

    private void openGui(Player p, Gui gui) {
        p.openInventory(gui.inv);
        clickSound(p);
    }

    private long gain(long amount, double rate) {
        return Math.max(1, Math.round(amount * rate));
    }

    // ---------- GUI nap ngan hang ----------

    private void openBankGui(Player p) {
        if (!checkBank(p)) return;
        FileConfiguration c = getConfig();
        final long min = c.getLong("order.min-amount", 10000);
        final long max = c.getLong("order.max-amount", 5000000);
        final double rate = c.getDouble("reward.money-rate", 1.0);

        List<Long> amounts = c.getLongList("gui.bank-amounts");
        if (amounts.isEmpty()) amounts = List.of(10000L, 20000L, 50000L, 100000L, 200000L, 500000L, 1000000L, 2000000L);
        final List<Long> list = amounts.stream().filter(a -> a >= min && a <= max).limit(28).collect(Collectors.toList());

        final int size = guiSize(list.size());
        final int fb = size - 9;
        Gui gui = newGui(g("bank-title", "&0Nạp tiền ngân hàng"), size);

        put(gui, 4, icon(Material.GOLD_BLOCK, "&6&lCOFFEECAT BANK",
                "&7Chuyển khoản qua &fVietQR",
                "&7Ngân hàng: &f" + c.getString("bank.bank-display-name", c.getString("bank.bank-id", "")),
                " ",
                "&7Nạp từ &f" + money(min) + "đ &7đến &f" + money(max) + "đ",
                "&7Quy đổi: &f1.000đ &7= &e" + money(gain(1000, rate)) + " &7tiền game"), null);

        int[] slots = layout(list.size());
        for (int i = 0; i < list.size(); i++) {
            final long a = list.get(i);
            put(gui, slots[i], icon(tier(i, list.size()), "&e&l" + money(a) + "đ",
                    "&7Nhận: &a" + money(gain(a, rate)) + " &7tiền game",
                    " ",
                    "&6» &fBấm để tạo mã QR"),
                    pl -> {
                        pl.closeInventory();
                        createOrder(pl, String.valueOf(a));
                    });
        }

        // Hang duoi: nhap so khac / dong / lenh dang cho
        put(gui, fb + 2, icon(Material.OAK_SIGN, "&b&lNhập số khác",
                "&7Tự gõ số tiền bạn muốn nạp",
                "&7(từ &f" + money(min) + "đ &7đến &f" + money(max) + "đ&7)",
                " ",
                "&6» &fBấm rồi gõ số tiền vào chat"),
                pl -> {
                    pl.closeInventory();
                    amountPrompts.put(pl.getUniqueId(), System.currentTimeMillis());
                    tell(pl, "gui-custom-prompt", Map.of("min", money(min), "max", money(max),
                            "seconds", String.valueOf(getConfig().getInt("card.prompt-seconds", 60))));
                });

        put(gui, fb + 4, icon(Material.BARRIER, "&c&lĐóng"), Player::closeInventory);

        final Order pend = pendingOf(p.getUniqueId());
        if (pend != null) {
            put(gui, fb + 6, icon(Material.PAPER, "&e&lLệnh đang chờ",
                    "&7Mã: &6" + pend.code,
                    "&7Số tiền: &f" + money(pend.amount) + "đ",
                    " ",
                    "&6» &fBấm để xem lại mã QR"),
                    pl -> {
                        pl.closeInventory();
                        Order cur = pendingOf(pl.getUniqueId());
                        if (cur == null) tell(pl, "no-pending", null);
                        else showInstructions(pl, cur);
                    });
            put(gui, fb + 7, icon(Material.RED_DYE, "&c&lHủy lệnh đang chờ",
                    "&7Hủy lệnh &6" + pend.code,
                    " ",
                    "&6» &fBấm để hủy"),
                    pl -> {
                        pl.closeInventory();
                        cancelPending(pl);
                    });
        } else {
            put(gui, fb + 6, icon(Material.CLOCK, "&a&lTự động cộng tiền",
                    "&7Chuyển khoản xong chờ khoảng",
                    "&71 phút, tiền vào game tự động."), null);
        }
        openGui(p, gui);
    }

    // ---------- GUI nap the cao ----------

    private String telcoColor(String telco) {
        return switch (telco) {
            case "VIETTEL" -> "&c";
            case "VINAPHONE" -> "&9";
            case "MOBIFONE" -> "&3";
            case "VIETNAMOBILE" -> "&6";
            case "GMOBILE" -> "&8";
            case "ZING" -> "&d";
            case "GATE" -> "&b";
            case "GARENA" -> "&4";
            case "VCOIN" -> "&2";
            default -> "&e";
        };
    }

    private Material telcoMaterial(String telco) {
        return switch (telco) {
            case "VIETTEL" -> Material.RED_CONCRETE;
            case "VINAPHONE" -> Material.BLUE_CONCRETE;
            case "MOBIFONE" -> Material.CYAN_CONCRETE;
            case "VIETNAMOBILE" -> Material.ORANGE_CONCRETE;
            case "GMOBILE" -> Material.GRAY_CONCRETE;
            case "ZING" -> Material.MAGENTA_CONCRETE;
            case "GATE" -> Material.LIGHT_BLUE_CONCRETE;
            case "GARENA" -> Material.RED_TERRACOTTA;
            case "VCOIN" -> Material.GREEN_CONCRETE;
            default -> Material.PAPER;
        };
    }

    private String prettyTelco(String telco) {
        return telco.isEmpty() ? telco : telco.charAt(0) + telco.substring(1).toLowerCase(Locale.ROOT);
    }

    private void openTelcoGui(Player p) {
        FileConfiguration c = getConfig();
        if (!checkCard(p)) return;
        final List<String> telcos = cardTelcos();
        final int size = guiSize(telcos.size());
        final int fb = size - 9;
        Gui gui = newGui(g("card-telco-title", "&0Nạp thẻ cào &8» &0Chọn nhà mạng"), size);

        put(gui, 4, icon(Material.GOLD_BLOCK, "&6&lNẠP THẺ CÀO",
                "&7Bước 1/3: chọn &fnhà mạng",
                "&7Bước 2/3: chọn &fmệnh giá",
                "&7Bước 3/3: gõ &fserial &7và &fmã thẻ &7vào chat",
                " ",
                "&7Quy đổi: &f1.000đ &7= &e" + money(gain(1000, c.getDouble("card.money-rate", 1.0))) + " &7tiền game"), null);

        int[] slots = layout(telcos.size());
        for (int i = 0; i < telcos.size(); i++) {
            final String t = telcos.get(i);
            put(gui, slots[i], icon(telcoMaterial(t), telcoColor(t) + "&l" + prettyTelco(t),
                    "&7Nạp thẻ cào &f" + prettyTelco(t),
                    " ",
                    "&6» &fBấm để chọn mệnh giá"),
                    pl -> openCardAmountGui(pl, t));
        }
        put(gui, fb + 4, icon(Material.BARRIER, "&c&lĐóng"), Player::closeInventory);
        openGui(p, gui);
    }

    private void openCardAmountGui(Player p, String telco) {
        FileConfiguration c = getConfig();
        if (!checkCard(p)) return;
        final double rate = c.getDouble("card.money-rate", 1.0);
        final List<Long> amounts = cardAmounts(telco).stream().limit(28).collect(Collectors.toList());
        final int size = guiSize(amounts.size());
        final int fb = size - 9;
        Gui gui = newGui(g("card-amount-title", "&0Nạp thẻ {telco} &8» &0Chọn mệnh giá")
                .replace("{telco}", prettyTelco(telco)), size);

        put(gui, 4, icon(telcoMaterial(telco), telcoColor(telco) + "&l" + prettyTelco(telco),
                "&7Bước 2/3: chọn &fmệnh giá thẻ",
                "&7Chọn đúng mệnh giá in trên thẻ."), null);

        int[] slots = layout(amounts.size());
        for (int i = 0; i < amounts.size(); i++) {
            final long a = amounts.get(i);
            put(gui, slots[i], icon(tier(i, amounts.size()), "&e&l" + money(a) + "đ",
                    "&7Nhà mạng: &f" + prettyTelco(telco),
                    "&7Nhận: &a" + money(gain(a, rate)) + " &7tiền game",
                    " ",
                    "&6» &fBấm rồi gõ serial & mã thẻ vào chat"),
                    pl -> {
                        pl.closeInventory();
                        startCardPrompt(pl, telco, a);
                    });
        }
        put(gui, fb + 2, icon(Material.ARROW, "&e&l« Quay lại", "&7Chọn lại nhà mạng"), pl -> openTelcoGui(pl));
        put(gui, fb + 4, icon(Material.BARRIER, "&c&lĐóng"), Player::closeInventory);
        put(gui, fb + 6, icon(Material.PAPER, "&c&lLưu ý",
                "&7Chọn đúng mệnh giá của thẻ.",
                "&7Sai mệnh giá có thể bị tính",
                "&7ít hơn hoặc không được cộng."), null);
        openGui(p, gui);
    }

    // ---------- Su kien GUI ----------

    @EventHandler
    public void onGuiClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Gui gui)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;
        Consumer<Player> action = gui.actions.get(e.getSlot());
        if (action == null || gui.used) return;
        gui.used = true; // chong bam 2 lan
        clickSound(p);
        Bukkit.getScheduler().runTask(this, () -> action.accept(p));
    }

    @EventHandler
    public void onGuiDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Gui) e.setCancelled(true);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (cmd.getName().equalsIgnoreCase("napthe")) {
            if (args.length == 1) {
                out.addAll(cardTelcos());
                out.add("huy");
            } else if (args.length == 2) {
                for (Long a : getConfig().getLongList("card.amounts")) out.add(String.valueOf(a));
            }
            return out.stream().filter(x -> x.toLowerCase().startsWith(args[args.length - 1].toLowerCase()))
                    .collect(Collectors.toList());
        }
        if (args.length == 1) {
            out.addAll(List.of("menu", "50000", "100000", "huy"));
            if (sender.hasPermission("coffeecatbank.admin")) out.addAll(List.of("reload", "pending", "status"));
        }
        return out.stream().filter(s -> s.toLowerCase().startsWith(args[args.length - 1].toLowerCase()))
                .collect(Collectors.toList());
    }
}
